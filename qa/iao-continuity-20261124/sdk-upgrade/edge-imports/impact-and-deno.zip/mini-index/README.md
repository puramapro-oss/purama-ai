# Impact préalable de l’alignement SDK Edge

**PASS sur le périmètre ciblé ; couverture globale PARTIELLE ; risque manuel HIGH.**

Un index isolé a été construit à partir de 12 fichiers copiés avant édition : 333 nœuds, 984 relations, 20 groupes et 9 flux. Alias `iao-edge-sdk-20261124`, stockage `/dev/shm/iao-edge-sdk-index-20261124/index`. Mémoire : heap Node 512 Mio, pool base 128 Mio, un worker à heap 128 Mio. Construction terminée avec le code 0. Aucune source produit ou index principal n’a été modifié par cette analyse.

Les quatre requêtes `impact` ont été exécutées en amont, profondeur 3, avec `--include-tests` et ont terminé avec le code 0 :

| Symbole | Appels directs représentés |
| --- | --- |
| `authorizeOts` | `contracts-ots-stamp`, `contracts-ots-verify` |
| `otsAdminClient` | `contracts-ots-verify` |
| `withBillingRequest` | `check-subscription`, `create-checkout`, `customer-portal` |
| `createSupabaseEntraidePorts` | `entraide-runtime` |

Les liens résolus portent une confiance de 0,85. Le classement LOW renvoyé par chaque requête ne concerne que la projection. Le changement global reste **HIGH** : 34 fichiers actifs, 35 occurrences, dont 21 fichiers Edge touchant notamment l’authentification et la facturation. La modification autorisée est uniquement la chaîne de version npm exacte 2.91.0 → 2.119.2 ; les corps, options, imports HTTPS et preuves historiques sont conservés.

FTS est désactivé. Le résolveur signale 33 accès de propriétés interlangages non reliés. Les tests JavaScript inclus n’apparaissent pas comme appelants résolus malgré `--include-tests`. Zéro flux affecté déclaré pour les symboles interrogés ne prouve pas que les chemins d’exécution sont absents. Le sous-ensemble ne remplace ni le différentiel mécanique ni les tests Deno et la CI.

`source-scope.json` contient les empreintes des 12 sources avant modification. `analyze.json` et `.log` conservent la construction. Chaque symbole a ses sorties JSON et journal ; `summary.json` regroupe les résultats et leurs limites. Le feu vert d’édition n’a été transmis à l’agent UI qu’après les quatre retours d’impact.
