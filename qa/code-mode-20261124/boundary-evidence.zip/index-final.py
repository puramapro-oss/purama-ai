from pathlib import Path
import os, json, subprocess, time, hashlib
root=Path('/workspace/scratch/200bdf486cef/purama-ai')
out=Path('/workspace/scratch/200bdf486cef/code-mode-next')
files=[
'karta/src/engine/tool-input.ts','karta/src/engine/types.ts','karta/src/engine/loop.ts','karta/src/engine/approval.ts',
'karta/src/claude/real.ts','karta/src/tools/apollo.ts','karta/src/tools/websearch.ts','karta/src/tools/pdf.ts',
'karta/src/tools/registry.ts','karta/src/tools/customRegistry.ts','karta/src/agents/index.ts','karta/src/api/server.ts',
'karta/src/queue/worker.ts','karta/src/chef/supervisor.ts']
assert all((root/f).is_file() for f in files)
scope=root/'.gitnexusignore'
old=scope.read_bytes() if scope.exists() else None
lines=['*','!karta/','!karta/src/']
for f in files:
 parts=Path(f).parts
 for i in range(3,len(parts)):
  s='!'+ '/'.join(parts[:i])+'/'
  if s not in lines: lines.append(s)
 lines.append('!'+f)
settings={
'NODE_OPTIONS':'--max-old-space-size=384 --max-semi-space-size=8',
'GITNEXUS_MEMORY':'off','GITNEXUS_WORKER_HEAP_MB':'256',
'GITNEXUS_WORKER_SUB_BATCH_MAX_BYTES':'262144','GITNEXUS_LBUG_BUFFER_POOL_SIZE':'134217728',
'GITNEXUS_LBUG_MAX_DB_SIZE':'1073741824','GITNEXUS_SERIAL_LBUG_LOAD':'1','GITNEXUS_PARSE_CHUNK_CONCURRENCY':'1',
'GITNEXUS_CONTENT_RETENTION':'none','GITNEXUS_STORAGE_PATH':'/dev/shm/iao-tool-boundary-200b-20261124',
'IAO_GITNEXUS_PACKAGE_JSON':'/workspace/scratch/200bdf486cef/tooling/node_modules/gitnexus/package.json'}
cmd=['node','--require',str(root/'qa/code-mode-20261124/gitnexus-native-resource-bound.cjs'),'/workspace/scratch/200bdf486cef/tooling/node_modules/gitnexus/dist/cli/index.js','analyze','--index-only','--skip-fts','--workers','1','--name','iao-tool-boundary-200b-20261124']
before={f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files}
start=time.monotonic()
rc=None
try:
 scope.write_text('\n'.join(lines)+'\n')
 with (out/'index-final.log').open('w') as log:
  rc=subprocess.run(cmd,cwd=root,env={**os.environ,**settings},stdout=log,stderr=subprocess.STDOUT,timeout=90).returncode
finally:
 if old is None: scope.unlink(missing_ok=True)
 else: scope.write_bytes(old)
 receipt={'command':cmd,'cwd':str(root),'environment':settings,'exit_code':rc,'elapsed_seconds':round(time.monotonic()-start,2),'scope':files,'source_hashes':before,'sources_unchanged':all(hashlib.sha256((root/f).read_bytes()).hexdigest()==h for f,h in before.items()),'scope_restored':(scope.read_bytes() if scope.exists() else None)==old,'limitations':'Focused graph of validator direct callers plus key entry points. Full repository consumers require textual review and tests; no claim of complete ecosystem graph.'}
 (out/'index-final.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({k:v for k,v in receipt.items() if k not in ['source_hashes','environment']},indent=2))
