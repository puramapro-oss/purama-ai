# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: navigation.spec.ts >> Navigation — Liens & Boutons >> Landing page — le CTA principal ouvre le formulaire d’inscription
- Location: tests/navigation.spec.ts:4:3

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('#hero').getByRole('link', { name: 'Commencer gratuitement', exact: true })
    - locator resolved to <a href="/signup" data-discover="true" class="w-full sm:w-auto">…</a>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is not stable
  - retrying click action
    - waiting for element to be visible, enabled and stable

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - button "Pause facultative" [ref=e3] [cursor=pointer]
  - region "Notifications alt+T"
  - generic [ref=e4]:
    - link "Aller au contenu principal" [ref=e5]:
      - /url: "#main"
    - main [ref=e6]:
      - region "Hero" [ref=e7]:
        - generic [ref=e8]:
          - navigation [ref=e9]:
            - generic [ref=e11]:
              - link "PURAMA AI" [ref=e12]:
                - /url: /
              - generic [ref=e19]:
                - link "Agents" [ref=e20]:
                  - /url: "#agents-section-wrapper"
                - link "Tarifs" [ref=e21]:
                  - /url: /pricing
                - link "Forge NEW" [ref=e22]:
                  - /url: /forge
                  - text: Forge
                  - generic [ref=e23]: NEW
                - link "Aide" [ref=e24]:
                  - /url: /aide
              - generic [ref=e25]:
                - link [ref=e26]:
                  - /url: /login
                  - button "Connexion" [ref=e27] [cursor=pointer]
                - link [ref=e28]:
                  - /url: /signup
                  - button "Commencer" [ref=e29] [cursor=pointer]
          - generic [ref=e30]:
            - generic [ref=e31]:
              - generic [ref=e32]: Plateforme française d'agents IA
              - heading "Tes agents IA travaillent pour toi" [level=1] [ref=e35]:
                - generic [ref=e36]: Tes agents IA
                - generic [ref=e37]: travaillent pour toi
              - paragraph [ref=e38]: Email, compta, juridique, partenariats. Configure une fois, laisse Purama gérer le reste.
              - generic [ref=e39]:
                - link [ref=e40]:
                  - /url: /signup
                  - button "Commencer gratuitement" [ref=e41] [cursor=pointer]
                - link [ref=e44]:
                  - /url: "#agents-section-wrapper"
                  - button "Voir les agents" [ref=e45] [cursor=pointer]
            - generic [ref=e47]:
              - link "Email Tri, réponses, relances" [ref=e49]:
                - /url: /dashboard/email-agent
                - generic [ref=e54]: Email
                - generic [ref=e55]: Tri, réponses, relances
              - link "Compta Factures, TVA, exports" [ref=e59]:
                - /url: /dashboard/compta-agent
                - generic [ref=e63]: Compta
                - generic [ref=e64]: Factures, TVA, exports
              - link "Juridique CGV, contrats, veille" [ref=e68]:
                - /url: /dashboard/legal-agent
                - generic [ref=e74]: Juridique
                - generic [ref=e75]: CGV, contrats, veille
              - link "Partenariats Prospects, cold emails" [ref=e79]:
                - /url: /dashboard/partner-agent
                - generic [ref=e86]: Partenariats
                - generic [ref=e87]: Prospects, cold emails
              - link "Créateur Compose ton agent" [ref=e91]:
                - /url: /dashboard/creator-agent
                - generic [ref=e103]: Créateur
                - generic [ref=e104]: Compose ton agent
              - link "Forge Sites & automations" [ref=e108]:
                - /url: /forge
                - generic [ref=e112]: Forge
                - generic [ref=e113]: Sites & automations
      - generic [ref=e120]:
        - strong [ref=e121]: "0"
        - text: action exécutée par nos employés IA cette semaine
      - region "Catalogue d'agents IA" [ref=e122]:
        - generic [ref=e127]:
          - generic [ref=e128]:
            - generic [ref=e129]: 0 Agents Spécialisés
            - heading "Vos Agents IA" [level=2] [ref=e134]
            - paragraph [ref=e135]: Chaque agent est un expert dans son domaine, prêt à transformer votre productivité.
          - generic [ref=e136]:
            - button "Activer Mes Agents IA" [ref=e137] [cursor=pointer]
            - paragraph [ref=e147]: 14 jours d'essai gratuit — Sans engagement
      - region "Module Compta" [ref=e148]:
        - generic [ref=e151]:
          - generic [ref=e152]:
            - generic [ref=e153]: Nouveau
            - heading "Purama Compta Votre DAF Virtuel IA" [level=2] [ref=e157]: Purama ComptaVotre DAF Virtuel IA
            - paragraph [ref=e158]: Automatise une grande partie de ta comptabilité grâce à l'IA. Saisie OCR, rapprochement bancaire, déclarations fiscales et pilotage financier — tout-en-un.
            - link [ref=e159]:
              - /url: /purama-compta
              - button "Découvrir Purama Compta" [ref=e160] [cursor=pointer]
          - generic [ref=e161]:
            - generic [ref=e162]:
              - heading "Saisie IA" [level=3] [ref=e166]
              - paragraph [ref=e167]: OCR + IA pour une saisie automatique en < 3 secondes
            - generic [ref=e168]:
              - heading "Facturation" [level=3] [ref=e173]
              - paragraph [ref=e174]: Factures, devis et relances automatiques conformes
            - generic [ref=e175]:
              - heading "Banque" [level=3] [ref=e179]
              - paragraph [ref=e180]: Rapprochement bancaire multi-banques en temps réel
            - generic [ref=e181]:
              - heading "Pilotage" [level=3] [ref=e186]
              - paragraph [ref=e187]: Tableaux de bord financiers et prévisions IA
      - region "Origin Forge" [ref=e188]:
        - generic [ref=e195]:
          - generic [ref=e196]:
            - generic [ref=e197]: ⚡ RÉVOLUTIONNAIRE
            - heading "Forge ton Agent IA avec un simple prompt" [level=2] [ref=e201]
            - paragraph [ref=e202]: Décris ton business en quelques mots. Origin Forge crée ton agent IA parfait — personnalité, compétences, widget chat — déployé en 60 secondes.
            - generic [ref=e203]:
              - generic [ref=e216]:
                - paragraph [ref=e217]: Compréhension naturelle
                - paragraph [ref=e218]: Écris comme tu parles, l'IA comprend tout
              - generic [ref=e223]:
                - paragraph [ref=e224]: Création instantanée
                - paragraph [ref=e225]: De l'idée à l'agent en 60 secondes
              - generic [ref=e234]:
                - paragraph [ref=e235]: 100% personnalisable
                - paragraph [ref=e236]: Nom, personnalité, compétences, apparence
              - generic [ref=e244]:
                - paragraph [ref=e245]: Déploiement 1 clic
                - paragraph [ref=e246]: Intégré à ton site automatiquement
            - generic [ref=e247]:
              - link "Créer mon Agent IA →" [ref=e248]:
                - /url: /forge
              - button "Voir la démo ↓" [ref=e249] [cursor=pointer]
          - generic [ref=e252]:
            - paragraph [ref=e253]: Décris ton agent...
            - paragraph [ref=e255]: Un
      - region "Démo Origin Forge" [ref=e257]:
        - generic [ref=e260]:
          - generic [ref=e261]:
            - paragraph [ref=e262]: IAO · Atelier de création
            - heading "Donnez forme à votre idée" [level=2] [ref=e263]
            - paragraph [ref=e264]: "Un site ou une application : décrivez votre projet et retrouvez les agents dans votre atelier."
          - generic [ref=e265]:
            - generic [ref=e266]: Votre projet
            - textbox "Votre projet" [ref=e267]:
              - /placeholder: Un site pour mon restaurant, avec le menu et les réservations…
            - generic [ref=e268]:
              - paragraph [ref=e269]: Consultez les projets disponibles, lancez une mission et suivez ses vérifications.
              - button "Ouvrir l’atelier" [disabled] [ref=e270]
            - generic "Exemples de projets" [ref=e277]:
              - button "Site de restaurant" [ref=e278] [cursor=pointer]: 🍽️ Site de restaurant
              - button "Boutique en ligne" [ref=e279] [cursor=pointer]: 🛍️ Boutique en ligne
              - button "Application de réservation" [ref=e280] [cursor=pointer]: 📅 Application de réservation
      - region "Communauté PURAMA" [ref=e281]:
        - generic [ref=e282]:
          - generic [ref=e283]:
            - heading "Rejoins la communauté PURAMA" [level=2] [ref=e284]
            - paragraph [ref=e285]: Parraine, participe aux concours et crée des projets à impact. Gagne de l'argent en contribuant à un monde meilleur.
          - generic [ref=e286]:
            - link "🤝 Parrainage Parraine tes amis et gagne 50% du 1er mois + 10% à vie. Débloque des paliers exclusifs ! Parrainer maintenant →" [ref=e288]:
              - /url: /parrainage
              - generic [ref=e289]: 🤝
              - heading "Parrainage" [level=3] [ref=e290]
              - paragraph [ref=e291]: Parraine tes amis et gagne 50% du 1er mois + 10% à vie. Débloque des paliers exclusifs !
              - generic [ref=e292]: Parrainer maintenant →
            - link "🎰 Jeux Concours Chaque semaine et chaque mois, une cagnotte à remporter. Plus tu parraines, plus tu as de chances ! Voir les concours →" [ref=e294]:
              - /url: /concours
              - generic [ref=e295]: 🎰
              - heading "Jeux Concours" [level=3] [ref=e296]
              - paragraph [ref=e297]: Chaque semaine et chaque mois, une cagnotte à remporter. Plus tu parraines, plus tu as de chances !
              - generic [ref=e298]: Voir les concours →
            - link "🏆 Classement Impact Soumets un projet à impact positif, l'IA l'évalue et les meilleurs se partagent 7% du CA. Découvrir le classement →" [ref=e300]:
              - /url: /classement
              - generic [ref=e301]: 🏆
              - heading "Classement Impact" [level=3] [ref=e302]
              - paragraph [ref=e303]: Soumets un projet à impact positif, l'IA l'évalue et les meilleurs se partagent 7% du CA.
              - generic [ref=e304]: Découvrir le classement →
      - region "Calculateur d'économies" [ref=e305]:
        - generic [ref=e311]:
          - generic [ref=e312]:
            - generic [ref=e313]: Calculateur de ROI
            - heading "Calculez Vos Économies" [level=2] [ref=e317]
            - paragraph [ref=e318]: Estimez le retour sur investissement de nos agents IA pour votre entreprise.
          - generic [ref=e319]:
            - generic [ref=e321]:
              - generic [ref=e322]:
                - generic [ref=e323]:
                  - generic [ref=e324]: Nombre d'employés
                  - generic [ref=e330]: "10"
                - slider "Nombre d'employés" [ref=e331] [cursor=pointer]: "10"
                - generic [ref=e332]:
                  - generic [ref=e333]: "1"
                  - generic [ref=e334]: "100"
              - generic [ref=e335]:
                - generic [ref=e336]:
                  - generic [ref=e337]: Heures de travail / semaine
                  - generic [ref=e341]: 40h
                - slider "Heures de travail / semaine" [ref=e342] [cursor=pointer]: "40"
                - generic [ref=e343]:
                  - generic [ref=e344]: 20h
                  - generic [ref=e345]: 60h
              - generic [ref=e346]:
                - generic [ref=e347]:
                  - generic [ref=e348]: Salaire moyen mensuel (€)
                  - generic [ref=e351]: 3 500€
                - slider "Salaire moyen mensuel (€)" [ref=e352] [cursor=pointer]: "3500"
                - generic [ref=e353]:
                  - generic [ref=e354]: 2 000€
                  - generic [ref=e355]: 10 000€
              - generic [ref=e356]:
                - generic [ref=e357]:
                  - generic [ref=e358]: Taux d'automatisation potentiel
                  - generic [ref=e361]: 30%
                - slider "Taux d'automatisation potentiel" [ref=e362] [cursor=pointer]: "30"
                - generic [ref=e363]:
                  - generic [ref=e364]: 10%
                  - generic [ref=e365]: 70%
            - generic [ref=e366]:
              - generic [ref=e367]:
                - generic [ref=e368]:
                  - generic [ref=e373]: 520h
                  - generic [ref=e374]: Heures économisées/mois
                - generic [ref=e375]:
                  - generic [ref=e379]: 10 500€
                  - generic [ref=e380]: Économies mensuelles
                - generic [ref=e381]:
                  - generic [ref=e386]: 15117%
                  - generic [ref=e387]: ROI annuel
                - generic [ref=e388]:
                  - generic [ref=e392]: 125 172€
                  - generic [ref=e393]: Gain net/an
              - generic [ref=e394]:
                - heading "Résumé de l'Investissement" [level=3] [ref=e395]
                - generic [ref=e399]:
                  - generic [ref=e400]:
                    - generic [ref=e401]: Investissement annuel
                    - generic [ref=e402]: 828€
                  - generic [ref=e403]:
                    - generic [ref=e404]: Économies annuelles
                    - generic [ref=e405]: 126 000€
                  - generic [ref=e406]:
                    - generic [ref=e407]: Gain net annuel
                    - generic [ref=e408]: +125 172€
                - button "Obtenir une Estimation Personnalisée" [ref=e409] [cursor=pointer]
      - region "Démo en direct sans inscription" [ref=e410]:
        - generic [ref=e413]:
          - generic [ref=e414]:
            - heading "Regarde un employé IA travailler" [level=2] [ref=e415]
            - paragraph [ref=e416]: Décris une situation, l'employé Email de Purama AI rédige un vrai brouillon — sans inscription.
          - generic [ref=e417]:
            - generic [ref=e418]:
              - textbox "Décris une situation d'email professionnel" [ref=e419]:
                - /placeholder: "Ex : Relancer un client qui n'a pas payé sa facture..."
              - button "Générer" [disabled] [ref=e420]
            - generic [ref=e424]:
              - button "Relancer un client qui n'a pas payé sa facture depuis 30 jours" [ref=e425] [cursor=pointer]
              - button "M'excuser auprès d'un client pour un retard de livraison" [ref=e426] [cursor=pointer]
              - button "Répondre à un prospect qui demande une réduction de prix" [ref=e427] [cursor=pointer]
      - region "Tarifs" [ref=e428]:
        - generic [ref=e433]:
          - generic [ref=e434]:
            - generic [ref=e435]: Tarification simple, compta toujours incluse
            - heading "Choisissez votre plan" [level=2] [ref=e439]
            - paragraph [ref=e440]: 5 employés IA, le module compta intégré, et la possibilité de créer vos propres agents. 14 jours d'essai Premium gratuit, sans carte bancaire.
            - paragraph [ref=e441]: 🛡️ Tes employés IA te font gagner du temps le 1er mois ou tu es remboursé
          - link [ref=e443]:
            - /url: /financer
            - paragraph [ref=e444]: 💰 La plupart de nos clients ne paient rien grace aux aides
            - paragraph [ref=e445]: Verifie ton eligibilite en 2 min →
          - generic [ref=e446]:
            - generic [ref=e447]:
              - heading "Découverte" [level=3] [ref=e453]
              - paragraph [ref=e454]: Goûte à Purama, sans engagement
              - generic [ref=e455]:
                - text: 0€
                - paragraph [ref=e456]: à vie
              - list [ref=e457]:
                - listitem [ref=e458]:
                  - generic [ref=e461]: 1 employé IA au choix
                - listitem [ref=e462]:
                  - generic [ref=e465]: 1 agent custom
                - listitem [ref=e466]:
                  - generic [ref=e469]: 100 actions / mois
                - listitem [ref=e470]:
                  - generic [ref=e473]: Module compta inclus
                - listitem [ref=e474]:
                  - generic [ref=e477]: Notifications push & email
                - listitem [ref=e478]:
                  - generic [ref=e481]: Communauté Discord
              - link "Commencer" [ref=e482]:
                - /url: /pricing
            - generic [ref=e483]:
              - heading "Starter" [level=3] [ref=e487]
              - paragraph [ref=e488]: Lance ton automatisation
              - generic [ref=e489]:
                - generic [ref=e490]: 33€
                - text: /mois
                - paragraph [ref=e491]:
                  - text: ou 27.50€/mois en annuel
                  - generic [ref=e492]: (−17%)
              - list [ref=e493]:
                - listitem [ref=e494]:
                  - generic [ref=e497]: 5 employés IA au choix
                - listitem [ref=e498]:
                  - generic [ref=e501]: 5 agents custom
                - listitem [ref=e502]:
                  - generic [ref=e505]: 1 500 actions / mois
                - listitem [ref=e506]:
                  - generic [ref=e509]: Module compta inclus
                - listitem [ref=e510]:
                  - generic [ref=e513]: Notifications prioritaires
                - listitem [ref=e514]:
                  - generic [ref=e517]: Support email < 24h
                - listitem [ref=e518]:
                  - generic [ref=e521]: 14 jours d'essai Premium gratuit, sans carte
              - link "Essai 14 jours" [ref=e522]:
                - /url: /pricing
            - generic [ref=e523]:
              - generic [ref=e524]: ⭐ POPULAIRE
              - heading "Premium" [level=3] [ref=e531]
              - paragraph [ref=e532]: Le choix des entrepreneurs sérieux
              - generic [ref=e533]:
                - generic [ref=e534]: 99€
                - text: /mois
                - paragraph [ref=e535]:
                  - text: ou 82.50€/mois en annuel
                  - generic [ref=e536]: (−17%)
              - list [ref=e537]:
                - listitem [ref=e538]:
                  - generic [ref=e541]: TOUS les employés IA
                - listitem [ref=e542]:
                  - generic [ref=e545]: 20 agents custom
                - listitem [ref=e546]:
                  - generic [ref=e549]: 6 000 actions / mois
                - listitem [ref=e550]:
                  - generic [ref=e553]: Module compta complet
                - listitem [ref=e554]:
                  - generic [ref=e557]: Marketplace agents
                - listitem [ref=e558]:
                  - generic [ref=e561]: Support prioritaire
                - listitem [ref=e562]:
                  - generic [ref=e565]: API complète
                - listitem [ref=e566]:
                  - generic [ref=e569]: 14 jours d'essai gratuit, sans carte
              - link "Essai 14 jours" [ref=e570]:
                - /url: /pricing
            - generic [ref=e571]:
              - heading "Ultime" [level=3] [ref=e575]
              - paragraph [ref=e576]: Tout, en priorité, sans limite basse.
              - generic [ref=e577]:
                - generic [ref=e578]: 199€
                - text: /mois
                - paragraph [ref=e579]:
                  - text: ou 165.83€/mois en annuel
                  - generic [ref=e580]: (−17%)
              - list [ref=e581]:
                - listitem [ref=e582]:
                  - generic [ref=e585]: TOUS les employés IA
                - listitem [ref=e586]:
                  - generic [ref=e589]: 100 agents custom
                - listitem [ref=e590]:
                  - generic [ref=e593]: 15 000 actions / mois
                - listitem [ref=e594]:
                  - generic [ref=e597]: Module compta complet
                - listitem [ref=e598]:
                  - generic [ref=e601]: Traitement prioritaire (file d'attente)
                - listitem [ref=e602]:
                  - generic [ref=e605]: Agent Créateur d'Agents en illimité
                - listitem [ref=e606]:
                  - generic [ref=e609]: Support VIP prioritaire
                - listitem [ref=e610]:
                  - generic [ref=e613]: API complète + webhooks
                - listitem [ref=e614]:
                  - generic [ref=e617]: 14 jours d'essai gratuit, sans carte
              - link "Essai 14 jours" [ref=e618]:
                - /url: /pricing
          - generic [ref=e623]:
            - paragraph [ref=e624]:
              - text: Le module Compta est inclus dans
              - strong [ref=e625]: tous les plans
              - text: ", même Free"
            - paragraph [ref=e626]: Bridge bancaire, catégorisation IA, déclarations TVA/IS, factures Factur-X. Aucun comptable nécessaire.
          - button "Afficher la comparaison détaillée" [ref=e628] [cursor=pointer]: Voir la comparaison détaillée
          - generic [ref=e631]:
            - heading "Questions fréquentes" [level=3] [ref=e632]
            - generic [ref=e633]:
              - heading [level=3] [ref=e635]:
                - button "Qu'est-ce qui est inclus dans Découverte ?" [ref=e636] [cursor=pointer]
              - heading [level=3] [ref=e640]:
                - button "C'est quoi une « action » ?" [ref=e641] [cursor=pointer]
              - heading [level=3] [ref=e645]:
                - button "Que se passe-t-il si je dépasse mon quota d'actions ?" [ref=e646] [cursor=pointer]
              - heading [level=3] [ref=e650]:
                - button "Puis-je changer de plan à tout moment ?" [ref=e651] [cursor=pointer]
              - heading [level=3] [ref=e655]:
                - button "Y a-t-il un essai gratuit ?" [ref=e656] [cursor=pointer]
              - heading [level=3] [ref=e660]:
                - button "Le module compta est-il vraiment inclus partout ?" [ref=e661] [cursor=pointer]
          - paragraph [ref=e664]: ✨ Sans engagement · 14 jours sans carte · Résiliable en 1 clic · Compta toujours incluse
      - region "Contact" [ref=e665]:
        - generic [ref=e671]:
          - generic [ref=e672]:
            - generic [ref=e673]: Parlons de Votre Projet
            - heading "Prêt à Automatiser ?" [level=2] [ref=e677]
            - paragraph [ref=e678]: Notre équipe d'experts est là pour vous accompagner dans votre transformation digitale.
          - generic [ref=e679]:
            - generic [ref=e680]:
              - generic [ref=e681]:
                - heading "Discutons de Vos Besoins" [level=3] [ref=e682]
                - paragraph [ref=e683]: Que vous soyez une startup ambitieuse ou une entreprise établie, nous avons la solution IA parfaite pour automatiser vos processus et booster votre productivité.
              - generic [ref=e684]:
                - generic [ref=e690]:
                  - generic [ref=e691]: Email
                  - generic [ref=e692]: contact@purama.fr
                - generic [ref=e697]:
                  - generic [ref=e698]: Téléphone
                  - generic [ref=e699]: "[À COMPLÉTER]"
                - generic [ref=e705]:
                  - generic [ref=e706]: Adresse
                  - generic [ref=e707]: Paris, France
              - generic [ref=e708]:
                - heading "Ce Que Vous Obtenez" [level=4] [ref=e709]
                - list [ref=e710]:
                  - listitem [ref=e711]: Consultation gratuite de 30 minutes
                  - listitem [ref=e714]: Analyse personnalisée de vos besoins
                  - listitem [ref=e717]: Démonstration des agents pertinents
                  - listitem [ref=e720]: Proposition sur mesure
            - generic [ref=e725]:
              - generic [ref=e726]:
                - generic [ref=e727]:
                  - generic [ref=e728]: Nom Complet *
                  - textbox "Nom Complet *" [ref=e729]:
                    - /placeholder: Jean Dupont
                - generic [ref=e730]:
                  - generic [ref=e731]: Email *
                  - textbox "Email *" [ref=e732]:
                    - /placeholder: jean@entreprise.fr
              - generic [ref=e733]:
                - generic [ref=e734]: Entreprise
                - textbox "Entreprise" [ref=e735]:
                  - /placeholder: Nom de votre entreprise
              - generic [ref=e736]:
                - generic [ref=e737]: Votre Message *
                - textbox "Votre Message *" [ref=e738]:
                  - /placeholder: Décrivez votre projet et vos besoins en automatisation...
              - button "Envoyer le Message" [ref=e739] [cursor=pointer]
    - contentinfo [ref=e743]:
      - generic [ref=e745]:
        - generic [ref=e746]:
          - generic [ref=e747]:
            - generic [ref=e748]: PURAMA AI
            - paragraph [ref=e753]: "La plateforme #1 d'agents IA pour automatiser votre entreprise et booster votre productivité."
            - generic [ref=e754]:
              - link "Twitter" [ref=e755]:
                - /url: "#"
              - link "LinkedIn" [ref=e758]:
                - /url: "#"
          - generic [ref=e763]:
            - heading "Produit" [level=4] [ref=e764]
            - list [ref=e765]:
              - listitem [ref=e766]:
                - link "Origin Forge" [ref=e767]:
                  - /url: /dashboard
              - listitem [ref=e768]:
                - link "Agents IA" [ref=e769]:
                  - /url: /#agents-section
              - listitem [ref=e770]:
                - link "Templates" [ref=e771]:
                  - /url: /dashboard
              - listitem [ref=e772]:
                - link "Galerie" [ref=e773]:
                  - /url: /dashboard
              - listitem [ref=e774]:
                - link "Purama Compta" [ref=e775]:
                  - /url: /purama-compta
              - listitem [ref=e776]:
                - link "Social AI Agent" [ref=e777]:
                  - /url: /agent
              - listitem [ref=e778]:
                - link "Tarifs" [ref=e779]:
                  - /url: /pricing
          - generic [ref=e780]:
            - heading "Communauté" [level=4] [ref=e781]
            - list [ref=e782]:
              - listitem [ref=e783]:
                - link "🤝 Parrainage" [ref=e784]:
                  - /url: /parrainage
              - listitem [ref=e785]:
                - link "🎰 Concours" [ref=e786]:
                  - /url: /concours
              - listitem [ref=e787]:
                - link "🏆 Classement" [ref=e788]:
                  - /url: /classement
              - listitem [ref=e789]:
                - link "Contact" [ref=e790]:
                  - /url: /#contact-section
          - generic [ref=e791]:
            - heading "Légal" [level=4] [ref=e792]
            - list [ref=e793]:
              - listitem [ref=e794]:
                - link "Mentions légales" [ref=e795]:
                  - /url: /mentions-legales
              - listitem [ref=e796]:
                - link "CGV" [ref=e797]:
                  - /url: /cgv
              - listitem [ref=e798]:
                - link "CGU" [ref=e799]:
                  - /url: /cgu
              - listitem [ref=e800]:
                - link "Politique de confidentialité" [ref=e801]:
                  - /url: /politique-de-confidentialite
              - listitem [ref=e802]:
                - link "Politique de cookies" [ref=e803]:
                  - /url: /politique-cookies
              - listitem [ref=e804]:
                - button "Gérer les cookies" [ref=e805] [cursor=pointer]
          - generic [ref=e806]:
            - heading "Partenaires" [level=4] [ref=e807]
            - paragraph [ref=e808]: Rejoignez notre programme partenaire et gagnez des commissions.
            - link "Devenir Partenaire" [ref=e809]:
              - /url: /influenceur/inscription
        - generic [ref=e810]:
          - paragraph [ref=e811]: "\"Sois le changement que tu veux voir dans le monde.\""
          - paragraph [ref=e812]: — Gandhi
        - generic [ref=e813]:
          - paragraph [ref=e814]: © 2025–2026 Purama AI — Tous droits réservés.
          - paragraph [ref=e815]: Sans engagement, résiliable à tout moment.
  - button "Ouvrir l'assistant PURA" [ref=e817] [cursor=pointer]
  - generic [ref=e819]:
    - generic [ref=e820]:
      - generic [ref=e824]:
        - paragraph [ref=e825]: Installer Purama AI
        - paragraph [ref=e826]: Comme une vraie app + notifications push
      - button "Fermer" [ref=e827] [cursor=pointer]
    - button "Installer" [ref=e831] [cursor=pointer]
```

# Test source

```ts
  1  | import { test, expect } from './public/fixtures';
  2  | 
  3  | test.describe('Navigation — Liens & Boutons', () => {
  4  |   test('Landing page — le CTA principal ouvre le formulaire d’inscription', async ({ page }) => {
  5  |     await page.goto('/', { waitUntil: 'networkidle' });
  6  | 
  7  |     const signup = page.locator('#hero').getByRole('link', { name: 'Commencer gratuitement', exact: true });
  8  |     await expect(signup).toHaveAttribute('href', '/signup');
> 9  |     await signup.click();
     |                  ^ Error: locator.click: Test timeout of 30000ms exceeded.
  10 |     await expect(page).toHaveURL(/\/signup$/);
  11 |     await expect(page.getByRole('heading', { name: 'Créer un compte', exact: true })).toBeVisible();
  12 |   });
  13 | 
  14 |   test('Login page — formulaire présent', async ({ page }) => {
  15 |     await page.goto('/login', { waitUntil: 'networkidle' });
  16 | 
  17 |     const emailInput = page.locator('input[type="email"], input[name="email"]');
  18 |     await expect(emailInput).toBeVisible();
  19 | 
  20 |     const passwordInput = page.locator('input[type="password"]');
  21 |     await expect(passwordInput).toBeVisible();
  22 | 
  23 |     const submitBtn = page.locator('button[type="submit"]');
  24 |     await expect(submitBtn).toBeVisible();
  25 |   });
  26 | 
  27 |   test('Signup page — formulaire complet', async ({ page }) => {
  28 |     await page.goto('/signup', { waitUntil: 'networkidle' });
  29 | 
  30 |     for (const field of ['#fullName', '#email', '#password', '#confirmPassword']) {
  31 |       await expect(page.locator(field)).toBeVisible();
  32 |     }
  33 | 
  34 |     const submitBtn = page.locator('button[type="submit"]');
  35 |     await expect(submitBtn).toBeVisible();
  36 |   });
  37 | 
  38 |   test('Pricing — cartes visibles', async ({ page }) => {
  39 |     await page.goto('/pricing', { waitUntil: 'networkidle' });
  40 | 
  41 |     // The route is lazy: wait for the four real cards, not a pre-render body.
  42 |     for (const name of ['Découverte', 'Starter', 'Premium', 'Ultime']) {
  43 |       await expect(page.getByRole('heading', { name, exact: true, level: 3 })).toBeVisible();
  44 |     }
  45 |   });
  46 | 
  47 |   test('Footer links — mentions légales, CGV, CGU', async ({ page }) => {
  48 |     await page.goto('/', { waitUntil: 'networkidle' });
  49 | 
  50 |     const footer = page.locator('footer');
  51 |     await expect(footer).toHaveCount(1);
  52 |     for (const path of ['/mentions-legales', '/cgv', '/cgu']) {
  53 |       const link = footer.locator(`a[href="${path}"]`);
  54 |       await expect(link).toHaveCount(1);
  55 |       await expect(link).toHaveAccessibleName(/\S/);
  56 |     }
  57 |   });
  58 | 
  59 |   test('Navigation — redirect non-auth vers login', async ({ page }) => {
  60 |     await page.goto('/dashboard', { waitUntil: 'networkidle' });
  61 |     // Should redirect to login
  62 |     await expect(page).toHaveURL(/\/login$/, { timeout: 10_000 });
  63 |     await expect(page.getByRole('button', { name: 'Se connecter', exact: true })).toBeVisible();
  64 |   });
  65 | });
  66 | 
```