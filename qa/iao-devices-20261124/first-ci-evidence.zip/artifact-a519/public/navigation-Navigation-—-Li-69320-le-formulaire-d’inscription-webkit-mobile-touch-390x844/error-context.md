# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: navigation.spec.ts >> Navigation — Liens & Boutons >> Landing page — le CTA principal ouvre le formulaire d’inscription
- Location: tests/navigation.spec.ts:4:3

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('#hero').getByRole('link', { name: 'Commencer gratuitement', exact: true })
    - locator resolved to <a href="/signup" data-discover="true" class="w-full sm:w-auto">…</a>
  - attempting click action
    2 × waiting for element to be visible, enabled and stable
      - element is not stable
    - retrying click action
    - waiting 20ms
    - waiting for element to be visible, enabled and stable

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - button "Pause facultative" [ref=e3] [cursor=pointer]
  - region "Notifications alt+T"
  - generic [ref=e4]:
    - link "Aller au contenu principal" [ref=e5]:
      - /url: "#main"
    - main [ref=e6]:
      - region "Hero" [ref=e7]:
        - generic [ref=e8]:
          - navigation [ref=e9]:
            - generic [ref=e11]:
              - link "PURAMA AI" [ref=e12]:
                - /url: /
              - button "Ouvrir le menu" [ref=e19] [cursor=pointer]
          - generic [ref=e21]:
            - generic [ref=e22]:
              - generic [ref=e23]: Plateforme française d'agents IA
              - heading "Tes agents IA travaillent pour toi" [level=1] [ref=e26]:
                - generic [ref=e27]: Tes agents IA
                - generic [ref=e28]: travaillent pour toi
              - paragraph [ref=e29]: Email, compta, juridique, partenariats. Configure une fois, laisse Purama gérer le reste.
              - generic [ref=e30]:
                - link [ref=e31]:
                  - /url: /signup
                  - button "Commencer gratuitement" [ref=e32] [cursor=pointer]
                - link [ref=e35]:
                  - /url: "#agents-section-wrapper"
                  - button "Voir les agents" [ref=e36] [cursor=pointer]
            - generic [ref=e38]:
              - link "Email Tri, réponses, relances" [ref=e40]:
                - /url: /dashboard/email-agent
                - generic [ref=e45]: Email
                - generic [ref=e46]: Tri, réponses, relances
              - link "Compta Factures, TVA, exports" [ref=e50]:
                - /url: /dashboard/compta-agent
                - generic [ref=e54]: Compta
                - generic [ref=e55]: Factures, TVA, exports
              - link "Juridique CGV, contrats, veille" [ref=e59]:
                - /url: /dashboard/legal-agent
                - generic [ref=e65]: Juridique
                - generic [ref=e66]: CGV, contrats, veille
              - link "Partenariats Prospects, cold emails" [ref=e70]:
                - /url: /dashboard/partner-agent
                - generic [ref=e77]: Partenariats
                - generic [ref=e78]: Prospects, cold emails
              - link "Créateur Compose ton agent" [ref=e82]:
                - /url: /dashboard/creator-agent
                - generic [ref=e94]: Créateur
                - generic [ref=e95]: Compose ton agent
              - link "Forge Sites & automations" [ref=e99]:
                - /url: /forge
                - generic [ref=e103]: Forge
                - generic [ref=e104]: Sites & automations
      - generic [ref=e111]:
        - strong [ref=e112]: "0"
        - text: action exécutée par nos employés IA cette semaine
      - region "Catalogue d'agents IA" [ref=e113]:
        - generic [ref=e118]:
          - generic [ref=e119]:
            - generic [ref=e120]: 0 Agents Spécialisés
            - heading "Vos Agents IA" [level=2] [ref=e125]
            - paragraph [ref=e126]: Chaque agent est un expert dans son domaine, prêt à transformer votre productivité.
          - generic [ref=e127]:
            - button "Activer Mes Agents IA" [ref=e128] [cursor=pointer]
            - paragraph [ref=e138]: 14 jours d'essai gratuit — Sans engagement
      - region "Module Compta" [ref=e139]:
        - generic [ref=e142]:
          - generic [ref=e143]:
            - generic [ref=e144]: Nouveau
            - heading "Purama Compta Votre DAF Virtuel IA" [level=2] [ref=e148]: Purama ComptaVotre DAF Virtuel IA
            - paragraph [ref=e149]: Automatise une grande partie de ta comptabilité grâce à l'IA. Saisie OCR, rapprochement bancaire, déclarations fiscales et pilotage financier — tout-en-un.
            - link [ref=e150]:
              - /url: /purama-compta
              - button "Découvrir Purama Compta" [ref=e151] [cursor=pointer]
          - generic [ref=e152]:
            - generic [ref=e153]:
              - heading "Saisie IA" [level=3] [ref=e157]
              - paragraph [ref=e158]: OCR + IA pour une saisie automatique en < 3 secondes
            - generic [ref=e159]:
              - heading "Facturation" [level=3] [ref=e164]
              - paragraph [ref=e165]: Factures, devis et relances automatiques conformes
            - generic [ref=e166]:
              - heading "Banque" [level=3] [ref=e170]
              - paragraph [ref=e171]: Rapprochement bancaire multi-banques en temps réel
            - generic [ref=e172]:
              - heading "Pilotage" [level=3] [ref=e177]
              - paragraph [ref=e178]: Tableaux de bord financiers et prévisions IA
      - region "Origin Forge" [ref=e179]:
        - generic [ref=e186]:
          - generic [ref=e187]:
            - generic [ref=e188]: ⚡ RÉVOLUTIONNAIRE
            - heading "Forge ton Agent IA avec un simple prompt" [level=2] [ref=e192]
            - paragraph [ref=e193]: Décris ton business en quelques mots. Origin Forge crée ton agent IA parfait — personnalité, compétences, widget chat — déployé en 60 secondes.
            - generic [ref=e194]:
              - generic [ref=e207]:
                - paragraph [ref=e208]: Compréhension naturelle
                - paragraph [ref=e209]: Écris comme tu parles, l'IA comprend tout
              - generic [ref=e214]:
                - paragraph [ref=e215]: Création instantanée
                - paragraph [ref=e216]: De l'idée à l'agent en 60 secondes
              - generic [ref=e225]:
                - paragraph [ref=e226]: 100% personnalisable
                - paragraph [ref=e227]: Nom, personnalité, compétences, apparence
              - generic [ref=e235]:
                - paragraph [ref=e236]: Déploiement 1 clic
                - paragraph [ref=e237]: Intégré à ton site automatiquement
            - generic [ref=e238]:
              - link "Créer mon Agent IA →" [ref=e239]:
                - /url: /forge
              - button "Voir la démo ↓" [ref=e240] [cursor=pointer]
          - generic [ref=e243]:
            - paragraph [ref=e244]: Décris ton agent...
            - paragraph [ref=e246]: U
      - region "Démo Origin Forge" [ref=e248]:
        - generic [ref=e251]:
          - generic [ref=e252]:
            - paragraph [ref=e253]: IAO · Atelier de création
            - heading "Donnez forme à votre idée" [level=2] [ref=e254]
            - paragraph [ref=e255]: "Un site ou une application : décrivez votre projet et retrouvez les agents dans votre atelier."
          - generic [ref=e256]:
            - generic [ref=e257]: Votre projet
            - textbox "Votre projet" [ref=e258]:
              - /placeholder: Un site pour mon restaurant, avec le menu et les réservations…
            - generic [ref=e259]:
              - paragraph [ref=e260]: Consultez les projets disponibles, lancez une mission et suivez ses vérifications.
              - button "Ouvrir l’atelier" [disabled] [ref=e261]
            - generic "Exemples de projets" [ref=e268]:
              - button "Site de restaurant" [ref=e269] [cursor=pointer]: 🍽️ Site de restaurant
              - button "Boutique en ligne" [ref=e270] [cursor=pointer]: 🛍️ Boutique en ligne
              - button "Application de réservation" [ref=e271] [cursor=pointer]: 📅 Application de réservation
      - region "Communauté PURAMA" [ref=e272]:
        - generic [ref=e273]:
          - generic [ref=e274]:
            - heading "Rejoins la communauté PURAMA" [level=2] [ref=e275]
            - paragraph [ref=e276]: Parraine, participe aux concours et crée des projets à impact. Gagne de l'argent en contribuant à un monde meilleur.
          - generic [ref=e277]:
            - link "🤝 Parrainage Parraine tes amis et gagne 50% du 1er mois + 10% à vie. Débloque des paliers exclusifs ! Parrainer maintenant →" [ref=e279]:
              - /url: /parrainage
              - generic [ref=e280]: 🤝
              - heading "Parrainage" [level=3] [ref=e281]
              - paragraph [ref=e282]: Parraine tes amis et gagne 50% du 1er mois + 10% à vie. Débloque des paliers exclusifs !
              - generic [ref=e283]: Parrainer maintenant →
            - link "🎰 Jeux Concours Chaque semaine et chaque mois, une cagnotte à remporter. Plus tu parraines, plus tu as de chances ! Voir les concours →" [ref=e285]:
              - /url: /concours
              - generic [ref=e286]: 🎰
              - heading "Jeux Concours" [level=3] [ref=e287]
              - paragraph [ref=e288]: Chaque semaine et chaque mois, une cagnotte à remporter. Plus tu parraines, plus tu as de chances !
              - generic [ref=e289]: Voir les concours →
            - link "🏆 Classement Impact Soumets un projet à impact positif, l'IA l'évalue et les meilleurs se partagent 7% du CA. Découvrir le classement →" [ref=e291]:
              - /url: /classement
              - generic [ref=e292]: 🏆
              - heading "Classement Impact" [level=3] [ref=e293]
              - paragraph [ref=e294]: Soumets un projet à impact positif, l'IA l'évalue et les meilleurs se partagent 7% du CA.
              - generic [ref=e295]: Découvrir le classement →
      - region "Calculateur d'économies" [ref=e296]:
        - generic [ref=e302]:
          - generic [ref=e303]:
            - generic [ref=e304]: Calculateur de ROI
            - heading "Calculez Vos Économies" [level=2] [ref=e308]
            - paragraph [ref=e309]: Estimez le retour sur investissement de nos agents IA pour votre entreprise.
          - generic [ref=e310]:
            - generic [ref=e312]:
              - generic [ref=e313]:
                - generic [ref=e314]:
                  - generic [ref=e315]: Nombre d'employés
                  - generic [ref=e321]: "10"
                - slider "Nombre d'employés" [ref=e322] [cursor=pointer]: "10"
                - generic [ref=e323]:
                  - generic [ref=e324]: "1"
                  - generic [ref=e325]: "100"
              - generic [ref=e326]:
                - generic [ref=e327]:
                  - generic [ref=e328]: Heures de travail / semaine
                  - generic [ref=e332]: 40h
                - slider "Heures de travail / semaine" [ref=e333] [cursor=pointer]: "40"
                - generic [ref=e334]:
                  - generic [ref=e335]: 20h
                  - generic [ref=e336]: 60h
              - generic [ref=e337]:
                - generic [ref=e338]:
                  - generic [ref=e339]: Salaire moyen mensuel (€)
                  - generic [ref=e342]: 3 500€
                - slider "Salaire moyen mensuel (€)" [ref=e343] [cursor=pointer]: "3500"
                - generic [ref=e344]:
                  - generic [ref=e345]: 2 000€
                  - generic [ref=e346]: 10 000€
              - generic [ref=e347]:
                - generic [ref=e348]:
                  - generic [ref=e349]: Taux d'automatisation potentiel
                  - generic [ref=e352]: 30%
                - slider "Taux d'automatisation potentiel" [ref=e353] [cursor=pointer]: "30"
                - generic [ref=e354]:
                  - generic [ref=e355]: 10%
                  - generic [ref=e356]: 70%
            - generic [ref=e357]:
              - generic [ref=e358]:
                - generic [ref=e359]:
                  - generic [ref=e364]: 520h
                  - generic [ref=e365]: Heures économisées/mois
                - generic [ref=e366]:
                  - generic [ref=e370]: 10 500€
                  - generic [ref=e371]: Économies mensuelles
                - generic [ref=e372]:
                  - generic [ref=e377]: 15117%
                  - generic [ref=e378]: ROI annuel
                - generic [ref=e379]:
                  - generic [ref=e383]: 125 172€
                  - generic [ref=e384]: Gain net/an
              - generic [ref=e385]:
                - heading "Résumé de l'Investissement" [level=3] [ref=e386]
                - generic [ref=e390]:
                  - generic [ref=e391]:
                    - generic [ref=e392]: Investissement annuel
                    - generic [ref=e393]: 828€
                  - generic [ref=e394]:
                    - generic [ref=e395]: Économies annuelles
                    - generic [ref=e396]: 126 000€
                  - generic [ref=e397]:
                    - generic [ref=e398]: Gain net annuel
                    - generic [ref=e399]: +125 172€
                - button "Obtenir une Estimation Personnalisée" [ref=e400] [cursor=pointer]
      - region "Démo en direct sans inscription" [ref=e401]:
        - generic [ref=e404]:
          - generic [ref=e405]:
            - heading "Regarde un employé IA travailler" [level=2] [ref=e406]
            - paragraph [ref=e407]: Décris une situation, l'employé Email de Purama AI rédige un vrai brouillon — sans inscription.
          - generic [ref=e408]:
            - generic [ref=e409]:
              - textbox "Décris une situation d'email professionnel" [ref=e410]:
                - /placeholder: "Ex : Relancer un client qui n'a pas payé sa facture..."
              - button "Générer" [disabled] [ref=e411]
            - generic [ref=e415]:
              - button "Relancer un client qui n'a pas payé sa facture depuis 30 jours" [ref=e416] [cursor=pointer]
              - button "M'excuser auprès d'un client pour un retard de livraison" [ref=e417] [cursor=pointer]
              - button "Répondre à un prospect qui demande une réduction de prix" [ref=e418] [cursor=pointer]
      - region "Tarifs" [ref=e419]:
        - generic [ref=e424]:
          - generic [ref=e425]:
            - generic [ref=e426]: Tarification simple, compta toujours incluse
            - heading "Choisissez votre plan" [level=2] [ref=e430]
            - paragraph [ref=e431]: 5 employés IA, le module compta intégré, et la possibilité de créer vos propres agents. 14 jours d'essai Premium gratuit, sans carte bancaire.
            - paragraph [ref=e432]: 🛡️ Tes employés IA te font gagner du temps le 1er mois ou tu es remboursé
          - link [ref=e434]:
            - /url: /financer
            - paragraph [ref=e435]: 💰 La plupart de nos clients ne paient rien grace aux aides
            - paragraph [ref=e436]: Verifie ton eligibilite en 2 min →
          - generic [ref=e437]:
            - generic [ref=e438]:
              - heading "Découverte" [level=3] [ref=e444]
              - paragraph [ref=e445]: Goûte à Purama, sans engagement
              - generic [ref=e446]:
                - text: 0€
                - paragraph [ref=e447]: à vie
              - list [ref=e448]:
                - listitem [ref=e449]:
                  - generic [ref=e452]: 1 employé IA au choix
                - listitem [ref=e453]:
                  - generic [ref=e456]: 1 agent custom
                - listitem [ref=e457]:
                  - generic [ref=e460]: 100 actions / mois
                - listitem [ref=e461]:
                  - generic [ref=e464]: Module compta inclus
                - listitem [ref=e465]:
                  - generic [ref=e468]: Notifications push & email
                - listitem [ref=e469]:
                  - generic [ref=e472]: Communauté Discord
              - link "Commencer" [ref=e473]:
                - /url: /pricing
            - generic [ref=e474]:
              - heading "Starter" [level=3] [ref=e478]
              - paragraph [ref=e479]: Lance ton automatisation
              - generic [ref=e480]:
                - generic [ref=e481]: 33€
                - text: /mois
                - paragraph [ref=e482]:
                  - text: ou 27.50€/mois en annuel
                  - generic [ref=e483]: (−17%)
              - list [ref=e484]:
                - listitem [ref=e485]:
                  - generic [ref=e488]: 5 employés IA au choix
                - listitem [ref=e489]:
                  - generic [ref=e492]: 5 agents custom
                - listitem [ref=e493]:
                  - generic [ref=e496]: 1 500 actions / mois
                - listitem [ref=e497]:
                  - generic [ref=e500]: Module compta inclus
                - listitem [ref=e501]:
                  - generic [ref=e504]: Notifications prioritaires
                - listitem [ref=e505]:
                  - generic [ref=e508]: Support email < 24h
                - listitem [ref=e509]:
                  - generic [ref=e512]: 14 jours d'essai Premium gratuit, sans carte
              - link "Essai 14 jours" [ref=e513]:
                - /url: /pricing
            - generic [ref=e514]:
              - generic [ref=e515]: ⭐ POPULAIRE
              - heading "Premium" [level=3] [ref=e522]
              - paragraph [ref=e523]: Le choix des entrepreneurs sérieux
              - generic [ref=e524]:
                - generic [ref=e525]: 99€
                - text: /mois
                - paragraph [ref=e526]:
                  - text: ou 82.50€/mois en annuel
                  - generic [ref=e527]: (−17%)
              - list [ref=e528]:
                - listitem [ref=e529]:
                  - generic [ref=e532]: TOUS les employés IA
                - listitem [ref=e533]:
                  - generic [ref=e536]: 20 agents custom
                - listitem [ref=e537]:
                  - generic [ref=e540]: 6 000 actions / mois
                - listitem [ref=e541]:
                  - generic [ref=e544]: Module compta complet
                - listitem [ref=e545]:
                  - generic [ref=e548]: Marketplace agents
                - listitem [ref=e549]:
                  - generic [ref=e552]: Support prioritaire
                - listitem [ref=e553]:
                  - generic [ref=e556]: API complète
                - listitem [ref=e557]:
                  - generic [ref=e560]: 14 jours d'essai gratuit, sans carte
              - link "Essai 14 jours" [ref=e561]:
                - /url: /pricing
            - generic [ref=e562]:
              - heading "Ultime" [level=3] [ref=e566]
              - paragraph [ref=e567]: Tout, en priorité, sans limite basse.
              - generic [ref=e568]:
                - generic [ref=e569]: 199€
                - text: /mois
                - paragraph [ref=e570]:
                  - text: ou 165.83€/mois en annuel
                  - generic [ref=e571]: (−17%)
              - list [ref=e572]:
                - listitem [ref=e573]:
                  - generic [ref=e576]: TOUS les employés IA
                - listitem [ref=e577]:
                  - generic [ref=e580]: 100 agents custom
                - listitem [ref=e581]:
                  - generic [ref=e584]: 15 000 actions / mois
                - listitem [ref=e585]:
                  - generic [ref=e588]: Module compta complet
                - listitem [ref=e589]:
                  - generic [ref=e592]: Traitement prioritaire (file d'attente)
                - listitem [ref=e593]:
                  - generic [ref=e596]: Agent Créateur d'Agents en illimité
                - listitem [ref=e597]:
                  - generic [ref=e600]: Support VIP prioritaire
                - listitem [ref=e601]:
                  - generic [ref=e604]: API complète + webhooks
                - listitem [ref=e605]:
                  - generic [ref=e608]: 14 jours d'essai gratuit, sans carte
              - link "Essai 14 jours" [ref=e609]:
                - /url: /pricing
          - generic [ref=e614]:
            - paragraph [ref=e615]:
              - text: Le module Compta est inclus dans
              - strong [ref=e616]: tous les plans
              - text: ", même Free"
            - paragraph [ref=e617]: Bridge bancaire, catégorisation IA, déclarations TVA/IS, factures Factur-X. Aucun comptable nécessaire.
          - button "Afficher la comparaison détaillée" [ref=e619] [cursor=pointer]: Voir la comparaison détaillée
          - generic [ref=e622]:
            - heading "Questions fréquentes" [level=3] [ref=e623]
            - generic [ref=e624]:
              - heading [level=3] [ref=e626]:
                - button "Qu'est-ce qui est inclus dans Découverte ?" [ref=e627] [cursor=pointer]
              - heading [level=3] [ref=e631]:
                - button "C'est quoi une « action » ?" [ref=e632] [cursor=pointer]
              - heading [level=3] [ref=e636]:
                - button "Que se passe-t-il si je dépasse mon quota d'actions ?" [ref=e637] [cursor=pointer]
              - heading [level=3] [ref=e641]:
                - button "Puis-je changer de plan à tout moment ?" [ref=e642] [cursor=pointer]
              - heading [level=3] [ref=e646]:
                - button "Y a-t-il un essai gratuit ?" [ref=e647] [cursor=pointer]
              - heading [level=3] [ref=e651]:
                - button "Le module compta est-il vraiment inclus partout ?" [ref=e652] [cursor=pointer]
          - paragraph [ref=e655]: ✨ Sans engagement · 14 jours sans carte · Résiliable en 1 clic · Compta toujours incluse
      - region "Contact" [ref=e656]:
        - generic [ref=e662]:
          - generic [ref=e663]:
            - generic [ref=e664]: Parlons de Votre Projet
            - heading "Prêt à Automatiser ?" [level=2] [ref=e668]
            - paragraph [ref=e669]: Notre équipe d'experts est là pour vous accompagner dans votre transformation digitale.
          - generic [ref=e670]:
            - generic [ref=e671]:
              - generic [ref=e672]:
                - heading "Discutons de Vos Besoins" [level=3] [ref=e673]
                - paragraph [ref=e674]: Que vous soyez une startup ambitieuse ou une entreprise établie, nous avons la solution IA parfaite pour automatiser vos processus et booster votre productivité.
              - generic [ref=e675]:
                - generic [ref=e681]:
                  - generic [ref=e682]: Email
                  - generic [ref=e683]: contact@purama.fr
                - generic [ref=e688]:
                  - generic [ref=e689]: Téléphone
                  - generic [ref=e690]: "[À COMPLÉTER]"
                - generic [ref=e696]:
                  - generic [ref=e697]: Adresse
                  - generic [ref=e698]: Paris, France
              - generic [ref=e699]:
                - heading "Ce Que Vous Obtenez" [level=4] [ref=e700]
                - list [ref=e701]:
                  - listitem [ref=e702]: Consultation gratuite de 30 minutes
                  - listitem [ref=e705]: Analyse personnalisée de vos besoins
                  - listitem [ref=e708]: Démonstration des agents pertinents
                  - listitem [ref=e711]: Proposition sur mesure
            - generic [ref=e716]:
              - generic [ref=e717]:
                - generic [ref=e718]:
                  - generic [ref=e719]: Nom Complet *
                  - textbox "Nom Complet *" [ref=e720]:
                    - /placeholder: Jean Dupont
                - generic [ref=e721]:
                  - generic [ref=e722]: Email *
                  - textbox "Email *" [ref=e723]:
                    - /placeholder: jean@entreprise.fr
              - generic [ref=e724]:
                - generic [ref=e725]: Entreprise
                - textbox "Entreprise" [ref=e726]:
                  - /placeholder: Nom de votre entreprise
              - generic [ref=e727]:
                - generic [ref=e728]: Votre Message *
                - textbox "Votre Message *" [ref=e729]:
                  - /placeholder: Décrivez votre projet et vos besoins en automatisation...
              - button "Envoyer le Message" [ref=e730] [cursor=pointer]
    - contentinfo [ref=e734]:
      - generic [ref=e736]:
        - generic [ref=e737]:
          - generic [ref=e738]:
            - generic [ref=e739]: PURAMA AI
            - paragraph [ref=e744]: "La plateforme #1 d'agents IA pour automatiser votre entreprise et booster votre productivité."
            - generic [ref=e745]:
              - link "Twitter" [ref=e746]:
                - /url: "#"
              - link "LinkedIn" [ref=e749]:
                - /url: "#"
          - generic [ref=e754]:
            - heading "Produit" [level=4] [ref=e755]
            - list [ref=e756]:
              - listitem [ref=e757]:
                - link "Origin Forge" [ref=e758]:
                  - /url: /dashboard
              - listitem [ref=e759]:
                - link "Agents IA" [ref=e760]:
                  - /url: /#agents-section
              - listitem [ref=e761]:
                - link "Templates" [ref=e762]:
                  - /url: /dashboard
              - listitem [ref=e763]:
                - link "Galerie" [ref=e764]:
                  - /url: /dashboard
              - listitem [ref=e765]:
                - link "Purama Compta" [ref=e766]:
                  - /url: /purama-compta
              - listitem [ref=e767]:
                - link "Social AI Agent" [ref=e768]:
                  - /url: /agent
              - listitem [ref=e769]:
                - link "Tarifs" [ref=e770]:
                  - /url: /pricing
          - generic [ref=e771]:
            - heading "Communauté" [level=4] [ref=e772]
            - list [ref=e773]:
              - listitem [ref=e774]:
                - link "🤝 Parrainage" [ref=e775]:
                  - /url: /parrainage
              - listitem [ref=e776]:
                - link "🎰 Concours" [ref=e777]:
                  - /url: /concours
              - listitem [ref=e778]:
                - link "🏆 Classement" [ref=e779]:
                  - /url: /classement
              - listitem [ref=e780]:
                - link "Contact" [ref=e781]:
                  - /url: /#contact-section
          - generic [ref=e782]:
            - heading "Légal" [level=4] [ref=e783]
            - list [ref=e784]:
              - listitem [ref=e785]:
                - link "Mentions légales" [ref=e786]:
                  - /url: /mentions-legales
              - listitem [ref=e787]:
                - link "CGV" [ref=e788]:
                  - /url: /cgv
              - listitem [ref=e789]:
                - link "CGU" [ref=e790]:
                  - /url: /cgu
              - listitem [ref=e791]:
                - link "Politique de confidentialité" [ref=e792]:
                  - /url: /politique-de-confidentialite
              - listitem [ref=e793]:
                - link "Politique de cookies" [ref=e794]:
                  - /url: /politique-cookies
              - listitem [ref=e795]:
                - button "Gérer les cookies" [ref=e796] [cursor=pointer]
          - generic [ref=e797]:
            - heading "Partenaires" [level=4] [ref=e798]
            - paragraph [ref=e799]: Rejoignez notre programme partenaire et gagnez des commissions.
            - link "Devenir Partenaire" [ref=e800]:
              - /url: /influenceur/inscription
        - generic [ref=e801]:
          - paragraph [ref=e802]: "\"La simplicite est la sophistication supreme.\""
          - paragraph [ref=e803]: — Leonard de Vinci
        - generic [ref=e804]:
          - paragraph [ref=e805]: © 2025–2026 Purama AI — Tous droits réservés.
          - paragraph [ref=e806]: Sans engagement, résiliable à tout moment.
  - button "Ouvrir l'assistant PURA" [ref=e808] [cursor=pointer]
```

# Test source

```ts
  1  | import { test, expect } from './public/fixtures';
  2  | 
  3  | test.describe('Navigation — Liens & Boutons', () => {
  4  |   test('Landing page — le CTA principal ouvre le formulaire d’inscription', async ({ page }) => {
  5  |     await page.goto('/', { waitUntil: 'networkidle' });
  6  | 
  7  |     const signup = page.locator('#hero').getByRole('link', { name: 'Commencer gratuitement', exact: true });
  8  |     await expect(signup).toHaveAttribute('href', '/signup');
> 9  |     await signup.click();
     |                  ^ Error: locator.click: Test timeout of 30000ms exceeded.
  10 |     await expect(page).toHaveURL(/\/signup$/);
  11 |     await expect(page.getByRole('heading', { name: 'Créer un compte', exact: true })).toBeVisible();
  12 |   });
  13 | 
  14 |   test('Login page — formulaire présent', async ({ page }) => {
  15 |     await page.goto('/login', { waitUntil: 'networkidle' });
  16 | 
  17 |     const emailInput = page.locator('input[type="email"], input[name="email"]');
  18 |     await expect(emailInput).toBeVisible();
  19 | 
  20 |     const passwordInput = page.locator('input[type="password"]');
  21 |     await expect(passwordInput).toBeVisible();
  22 | 
  23 |     const submitBtn = page.locator('button[type="submit"]');
  24 |     await expect(submitBtn).toBeVisible();
  25 |   });
  26 | 
  27 |   test('Signup page — formulaire complet', async ({ page }) => {
  28 |     await page.goto('/signup', { waitUntil: 'networkidle' });
  29 | 
  30 |     for (const field of ['#fullName', '#email', '#password', '#confirmPassword']) {
  31 |       await expect(page.locator(field)).toBeVisible();
  32 |     }
  33 | 
  34 |     const submitBtn = page.locator('button[type="submit"]');
  35 |     await expect(submitBtn).toBeVisible();
  36 |   });
  37 | 
  38 |   test('Pricing — cartes visibles', async ({ page }) => {
  39 |     await page.goto('/pricing', { waitUntil: 'networkidle' });
  40 | 
  41 |     // The route is lazy: wait for the four real cards, not a pre-render body.
  42 |     for (const name of ['Découverte', 'Starter', 'Premium', 'Ultime']) {
  43 |       await expect(page.getByRole('heading', { name, exact: true, level: 3 })).toBeVisible();
  44 |     }
  45 |   });
  46 | 
  47 |   test('Footer links — mentions légales, CGV, CGU', async ({ page }) => {
  48 |     await page.goto('/', { waitUntil: 'networkidle' });
  49 | 
  50 |     const footer = page.locator('footer');
  51 |     await expect(footer).toHaveCount(1);
  52 |     for (const path of ['/mentions-legales', '/cgv', '/cgu']) {
  53 |       const link = footer.locator(`a[href="${path}"]`);
  54 |       await expect(link).toHaveCount(1);
  55 |       await expect(link).toHaveAccessibleName(/\S/);
  56 |     }
  57 |   });
  58 | 
  59 |   test('Navigation — redirect non-auth vers login', async ({ page }) => {
  60 |     await page.goto('/dashboard', { waitUntil: 'networkidle' });
  61 |     // Should redirect to login
  62 |     await expect(page).toHaveURL(/\/login$/, { timeout: 10_000 });
  63 |     await expect(page.getByRole('button', { name: 'Se connecter', exact: true })).toBeVisible();
  64 |   });
  65 | });
  66 | 
```