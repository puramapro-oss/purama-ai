# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: touch.spec.ts >> touch controls preserve a draft through viewport rotation and stop the same response
- Location: qa/iao-devices-20261124/browser/touch.spec.ts:4:1

# Error details

```
Error: expect(locator).toBeInViewport() failed

Locator:  getByRole('textbox', { name: 'Votre message' })
Expected: in viewport
Received: viewport ratio 0.745312511920929
Timeout:  5000ms

Call log:
  - Expect "toBeInViewport" getByRole('textbox', { name: 'Votre message' }) with timeout 5000ms
  - waiting for getByRole('textbox', { name: 'Votre message' })
    12 × locator resolved to <input maxlength="2000" aria-label="Votre message" placeholder="Posez votre question..." value="Conserver mon projet pendant la rotation. 🧭" class="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disab…/>
       - unexpected value "viewport ratio 0.745312511920929"

```

```yaml
- textbox "Votre message":
  - /placeholder: Posez votre question...
  - text: Conserver mon projet pendant la rotation. 🧭
```

# Test source

```ts
  1  | import { test, expect } from '../../../tests/chat/fixtures';
  2  | import type { Plan } from '../../../tests/chat/transport';
  3  | 
  4  | test('touch controls preserve a draft through viewport rotation and stop the same response', async ({ page, browser, browserName, viewport }, testInfo) => {
  5  |   expect(viewport).not.toBeNull();
  6  |   await page.goto('/tests/chat/index.html');
  7  |   await page.getByRole('button', { name: "Ouvrir l'assistant PURA" }).tap();
  8  |   const dialog = page.getByRole('dialog');
  9  |   const input = page.getByRole('textbox', { name: 'Votre message' });
  10 |   await expect(dialog).toContainText('Décrivez ce que vous souhaitez faire.');
  11 |   await expect(dialog).toBeInViewport({ ratio: 1 });
  12 |   const prompt = 'Conserver mon projet pendant la rotation. 🧭';
  13 |   await input.fill(prompt);
  14 | 
  15 |   const landscape = { width: viewport!.height, height: viewport!.width };
  16 |   await page.setViewportSize(landscape);
  17 |   await expect(dialog).toBeInViewport({ ratio: 1 });
> 18 |   await expect(input).toBeInViewport({ ratio: 1 });
     |                       ^ Error: expect(locator).toBeInViewport() failed
  19 |   await expect(input).toHaveValue(prompt);
  20 |   const responsePlan: Plan = { stream: true, text: 'Fragment tactile provisoire' };
  21 |   await page.evaluate(plan => { window.__chatHarness.plans.chatbot = [plan]; }, responsePlan);
  22 |   await page.getByRole('button', { name: 'Envoyer le message' }).tap();
  23 |   await expect(dialog).toContainText(responsePlan.text!);
  24 |   const stop = page.getByRole('button', { name: 'Arrêter la réponse' });
  25 |   await expect(stop).toBeInViewport({ ratio: 1 });
  26 |   await stop.tap();
  27 |   await expect(dialog).not.toContainText(responsePlan.text!);
  28 |   await expect(input).toHaveValue(prompt);
  29 |   const calls = await page.evaluate(() => window.__chatHarness.calls.filter(call => call.key === 'chatbot'));
  30 |   expect(calls).toHaveLength(1);
  31 |   expect(calls[0].aborted).toBe(true);
  32 | 
  33 |   await page.setViewportSize(viewport!);
  34 |   await expect(dialog).toBeInViewport({ ratio: 1 });
  35 |   await expect(input).toHaveValue(prompt);
  36 |   await testInfo.attach('emulated-touch-environment.json', {
  37 |     body: Buffer.from(JSON.stringify({
  38 |       scope: 'Linux browser and emulated touch/viewport; no physical device or native virtual keyboard',
  39 |       browserName,
  40 |       browserVersion: browser.version(),
  41 |       project: testInfo.project.name,
  42 |       portrait: viewport,
  43 |       landscape,
  44 |       navigator: await page.evaluate(() => ({
  45 |         userAgent: navigator.userAgent,
  46 |         maxTouchPoints: navigator.maxTouchPoints,
  47 |         innerWidth,
  48 |         innerHeight,
  49 |         coarsePointer: matchMedia('(pointer: coarse)').matches,
  50 |       })),
  51 |     }, null, 2)),
  52 |     contentType: 'application/json',
  53 |   });
  54 |   await page.getByRole('button', { name: "Fermer l'assistant" }).tap();
  55 |   await expect(dialog).toBeHidden();
  56 | });
  57 | 
```