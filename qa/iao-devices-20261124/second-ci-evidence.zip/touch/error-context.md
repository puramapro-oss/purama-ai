# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: touch.spec.ts >> touch controls preserve a draft through viewport rotation and stop the same response
- Location: qa/iao-devices-20261124/browser/touch.spec.ts:4:1

# Error details

```
Error: expect(locator).toBeInViewport() failed

Locator:  getByRole('dialog').getByRole('button', { name: 'Comment fonctionnent les agents ?', exact: true })
Expected: in viewport
Received: viewport ratio 0.99609375
Timeout:  5000ms

Call log:
  - Expect "toBeInViewport" getByRole('dialog').getByRole('button', { name: 'Comment fonctionnent les agents ?', exact: true }) with timeout 5000ms
  - waiting for getByRole('dialog').getByRole('button', { name: 'Comment fonctionnent les agents ?', exact: true })
    14 × locator resolved to <button class="text-xs px-3 py-1.5 rounded-full bg-primary/10 text-primary hover:bg-primary/20 transition-colors">Comment fonctionnent les agents ?</button>
       - unexpected value "viewport ratio 0.99609375"

```

```yaml
- button "Comment fonctionnent les agents ?"
```

# Test source

```ts
  1  | import { test, expect } from '../../../tests/chat/fixtures';
  2  | import type { Plan } from '../../../tests/chat/transport';
  3  | 
  4  | test('touch controls preserve a draft through viewport rotation and stop the same response', async ({ page, browser, browserName, viewport }, testInfo) => {
  5  |   expect(viewport).not.toBeNull();
  6  |   await page.goto('/tests/chat/index.html');
  7  |   await page.getByRole('button', { name: "Ouvrir l'assistant PURA" }).tap();
  8  |   const dialog = page.getByRole('dialog');
  9  |   const input = page.getByRole('textbox', { name: 'Votre message' });
  10 |   await expect(dialog).toContainText('Décrivez ce que vous souhaitez faire.');
  11 |   await expect(dialog).toBeInViewport({ ratio: 1 });
  12 |   const prompt = 'Conserver mon projet pendant la rotation. 🧭';
  13 |   await input.fill(prompt);
  14 | 
  15 |   const landscape = { width: viewport!.height, height: viewport!.width };
  16 |   await page.setViewportSize(landscape);
  17 |   await expect(dialog).toBeInViewport({ ratio: 1 });
  18 |   await expect(input).toBeInViewport({ ratio: 1 });
  19 |   await expect(input).toHaveValue(prompt);
  20 |   // Scrolling auxiliary content must keep the header and composer usable.
  21 |   for (const name of [
  22 |     'Quels sont vos tarifs ?',
  23 |     'Comment fonctionnent les agents ?',
  24 |     "Programme d'affiliation",
  25 |     'Comment connecter Gmail ?',
  26 |   ]) {
  27 |     const suggestion = dialog.getByRole('button', { name, exact: true });
  28 |     await suggestion.scrollIntoViewIfNeeded();
> 29 |     await expect(suggestion).toBeInViewport({ ratio: 1 });
     |                              ^ Error: expect(locator).toBeInViewport() failed
  30 |     await expect(page.getByRole('button', { name: "Fermer l'assistant" })).toBeInViewport({ ratio: 1 });
  31 |     await expect(input).toBeInViewport({ ratio: 1 });
  32 |   }
  33 |   const responsePlan: Plan = { stream: true, text: 'Fragment tactile provisoire' };
  34 |   await page.evaluate(plan => { window.__chatHarness.plans.chatbot = [plan]; }, responsePlan);
  35 |   await page.getByRole('button', { name: 'Envoyer le message' }).tap();
  36 |   await expect(dialog).toContainText(responsePlan.text!);
  37 |   const stop = page.getByRole('button', { name: 'Arrêter la réponse' });
  38 |   await expect(stop).toBeInViewport({ ratio: 1 });
  39 |   await stop.tap();
  40 |   await expect(dialog).not.toContainText(responsePlan.text!);
  41 |   await expect(input).toHaveValue(prompt);
  42 |   const calls = await page.evaluate(() => window.__chatHarness.calls.filter(call => call.key === 'chatbot'));
  43 |   expect(calls).toHaveLength(1);
  44 |   expect(calls[0].aborted).toBe(true);
  45 | 
  46 |   await page.setViewportSize(viewport!);
  47 |   await expect(dialog).toBeInViewport({ ratio: 1 });
  48 |   await expect(input).toHaveValue(prompt);
  49 |   await testInfo.attach('emulated-touch-environment.json', {
  50 |     body: Buffer.from(JSON.stringify({
  51 |       scope: 'Linux browser and emulated touch/viewport; no physical device or native virtual keyboard',
  52 |       browserName,
  53 |       browserVersion: browser.version(),
  54 |       project: testInfo.project.name,
  55 |       portrait: viewport,
  56 |       landscape,
  57 |       navigator: await page.evaluate(() => ({
  58 |         userAgent: navigator.userAgent,
  59 |         maxTouchPoints: navigator.maxTouchPoints,
  60 |         innerWidth,
  61 |         innerHeight,
  62 |         coarsePointer: matchMedia('(pointer: coarse)').matches,
  63 |       })),
  64 |     }, null, 2)),
  65 |     contentType: 'application/json',
  66 |   });
  67 |   await page.getByRole('button', { name: "Fermer l'assistant" }).tap();
  68 |   await expect(dialog).toBeHidden();
  69 | });
  70 | 
```